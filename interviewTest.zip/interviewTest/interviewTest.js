// import { LightningElement , track , wire} from 'lwc';
// import getAccounts from '@salesforce/apex/AccountControllers.getAccounts';
// import getContactsByAccount from '@salesforce/apex/AccountControllers.getContactsByAccount';
// import getOpportunitiesByAccount from '@salesforce/apex/AccountControllers.getOpportunityByAccount';
// export default class InterviewTest extends LightningElement {


// @track accounts =[];
// @track selectedAccountId;
// @track contacts =[];
// @track opportunities =[];


// @wire(getAccounts)
// wiredAccounts({error,data}){
//  if(data){

//     this.account = data.map(acc => ({label: acc.Name, value:acc.Id}));
//  }else if(error){

//     console.error(error);
//  }
// }

//  handleAccountChange(event){
//     this.selectedAccountId = event.target.value;
    
//     getContactsByAccount({ accountId: this.selectedAccountId}).then(result => {
//     this.contacts = result;
// }).catch(error => {
//     console.error(error);
// });

// getOpportunitiesByAccount({ accountId: this.selectedAccountId}).then(result => {
//     this.opportunities = result;
// }).catch(error=>{
//    console.log(error);
   
// });

// }

// }

import { LightningElement, track, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountControllers.getAccounts';
import getContactsByAccount from '@salesforce/apex/AccountControllers.getContactsByAccount';
import getOpportunitiesByAccount from '@salesforce/apex/AccountControllers.getOpportunityByAccount'; 
// ⚠️ check Apex method spelling: plural vs singular

export default class interviewTest extends LightningElement {
    @track accounts = [];
    @track selectedAccountId;
    @track contacts = [];
    @track opportunities = [];

    // Define columns in JS (✅ Best Practice)
    contactColumns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Email', fieldName: 'Email' },
        { label: 'Phone', fieldName: 'Phone' }
    ];

    opportunityColumns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Stage', fieldName: 'StageName' },
        { label: 'Close Date', fieldName: 'CloseDate', type: 'date' },
        { label: 'Amount', fieldName: 'Amount', type: 'currency' }
    ];

    // Load accounts
    @wire(getAccounts)
    wiredAccounts({ error, data }) {
        if (data) {
            this.accounts = data.map(acc => ({
                label: acc.Name,
                value: acc.Id
            }));
        } else if (error) {
            console.error(error);
        }
    }

    // Handle account selection
    handleAccountChange(event) {
        this.selectedAccountId = event.detail.value;

        // Get Contacts
        getContactsByAccount({ accountId: this.selectedAccountId })
            .then(result => {
                this.contacts = result;
            })
            .catch(error => {
                console.error(error);
            });

        // Get Opportunities
        getOpportunitiesByAccount({ accountId: this.selectedAccountId })
            .then(result => {
                this.opportunities = result;
            })
            .catch(error => {
                console.error(error);
            });
    }
}